// have u missed something 

//  chk prooooperlyyyyyyyyyyyy