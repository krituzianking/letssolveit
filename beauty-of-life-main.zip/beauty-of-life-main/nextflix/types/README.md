# Nextflix 
welcome welcome !! 
## Demo
sorry unavailable:)

## Built with LOve


## Running the project
pls dont run me

will u listen to this inocent voice
#### `yarn start`

is the voice really inocent ^^






































"Life is a canvas, and we are the artists, painting it with the vibrant hues of our emotions and experiences, while understanding what the colours say is the key which we need to decipher."


![alt text](image-1.png)
