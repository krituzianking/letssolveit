module.exports = {
    singleQuote: true,
    printWidth: 120,
    tabWidth: 2,
    trailingComma: 'none',
    jsxBracketSameLine: true,
    jsxSingleQuote: true,
    arrowParens: 'avoid'
};