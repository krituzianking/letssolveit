export enum ROUTES {
  HOME = '/',
  BROWSE = '/browse',
  LATEST = '/latest'
}